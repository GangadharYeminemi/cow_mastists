import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GRU, Dense
from tensorflow.keras.utils import to_categorical
import joblib
from scipy.stats import mode
import matplotlib.pyplot as plt
import re
import os

# Function to convert stagoFLactation to days
def convert_lactation_to_days(stage):
    stage = str(stage).lower().strip()
    if not stage or 'dry' in stage:
        return 0
    match = re.match(r'(\d*\.?\d*)\s*(d|m)', stage)
    if match:
        value, unit = match.groups()
        value = float(value) if value else 0
        return value if unit == 'd' else value * 30
    print(f"Warning: Invalid stagoFLactation format '{stage}', defaulting to 0")
    return 0

# Verify dataset exists
if not os.path.exists('Cleaned_Mastitis_Data.xlsx'):
    raise FileNotFoundError("Cleaned_Mastitis_Data.xlsx not found in current directory")

# Load data
data = pd.read_excel('Cleaned_Mastitis_Data.xlsx')

# Preprocess features
# Numerical columns: convert to numeric and fill NaN with median
for col in ['age_in_years', 'parity', 'pH', 'cond.', 'CMT']:
    data[col] = pd.to_numeric(data[col], errors='coerce')
    if data[col].isna().any():
        print(f"Filling {data[col].isna().sum()} NaN values in {col} with median")
        data[col] = data[col].fillna(data[col].median())

# Convert stagoFLactation
data['stagoFLactation'] = data['stagoFLactation'].apply(convert_lactation_to_days)

# Clean and encode G/BA
data['G/BA'] = data['G/BA'].fillna('n')
data['G/BA'] = data['G/BA'].str.lower().str.strip()
data['G/BA'] = data['G/BA'].map({'p': 1, 'n': 0})
if data['G/BA'].isna().any():
    unmapped = data[data['G/BA'].isna()]['G/BA'].unique()
    raise ValueError(f"Unmapped G/BA values: {unmapped}")

# Map target variable
data['type'] = data['type'].map({'cm': 'clinical mastitis', 'scm': 'subclinical mastitis'})
if data['type'].isna().any():
    print(f"Warning: {data['type'].isna().sum()} NaN values in 'type', dropping rows")
    data = data.dropna(subset=['type'])

# Simulate normal cases
normal_cases = pd.DataFrame({
    'age_in_years': np.random.uniform(2, 7, 100),
    'parity': np.random.randint(1, 5, 100),
    'stagoFLactation': np.random.uniform(0, 180, 100),
    'G/BA': [0] * 100,
    'pH': np.random.uniform(6.6, 6.8, 100),
    'cond.': np.random.uniform(4, 6, 100),
    'CMT': [0] * 100,
    'type': ['normal'] * 100
})
data = pd.concat([data, normal_cases], ignore_index=True)

# Encode target variable
le = LabelEncoder()
data['type'] = le.fit_transform(data['type'])  # normal: 2, clinical mastitis: 0, subclinical mastitis: 1

# Features and target
X = data[['age_in_years', 'parity', 'stagoFLactation', 'G/BA', 'pH', 'cond.', 'CMT']]
y = data['type']

# Debug: Check data types and non-numerical values
print("Feature matrix X data types:")
print(X.dtypes)
for col in X.columns:
    non_numeric = X[col][X[col].apply(lambda x: not isinstance(x, (int, float)))]
    if not non_numeric.empty:
        print(f"Non-numerical values in {col}: {non_numeric.unique()}")

# Verify numerical values
if not np.all(X.dtypes.apply(lambda x: np.issubdtype(x, np.number))):
    raise ValueError("Non-numerical values found in feature matrix X")

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Save scaler and label encoder
joblib.dump(scaler, 'scaler.pkl')
joblib.dump(le, 'label_encoder.pkl')

# Reshape for GRU
X_train_gru = X_train_scaled.reshape((X_train_scaled.shape[0], 1, X_train_scaled.shape[1]))
X_test_gru = X_test_scaled.reshape((X_test_scaled.shape[0], 1, X_test_scaled.shape[1]))
y_train_cat = to_categorical(y_train)
y_test_cat = to_categorical(y_test)

# Train LightGBM
lgbm = LGBMClassifier(random_state=42)
lgbm.fit(X_train_scaled, y_train)
lgbm_pred = lgbm.predict(X_test_scaled)
lgbm_accuracy = accuracy_score(y_test, lgbm_pred)

# Train XGBoost
xgb = XGBClassifier(random_state=42, eval_metric='mlogloss')
xgb.fit(X_train_scaled, y_train)
xgb_pred = xgb.predict(X_test_scaled)
xgb_accuracy = accuracy_score(y_test, xgb_pred)

# Train GRU
gru_model = Sequential([
    GRU(64, input_shape=(1, X_train_scaled.shape[1]), activation='tanh'),
    Dense(32, activation='relu'),
    Dense(3, activation='softmax')
])
gru_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
gru_model.fit(X_train_gru, y_train_cat, epochs=50, batch_size=32, verbose=0)
gru_pred = np.argmax(gru_model.predict(X_test_gru), axis=1)
gru_accuracy = accuracy_score(y_test, gru_pred)

# Ensemble predictions
ensemble_pred = mode([lgbm_pred, xgb_pred, gru_pred], axis=0)[0].flatten()
ensemble_accuracy = accuracy_score(y_test, ensemble_pred)

# Save models
joblib.dump(lgbm, 'lgbm_model.pkl')
joblib.dump(xgb, 'xgb_model.pkl')
gru_model.save('gru_model.h5')

# Plot actual vs predicted
n_samples = 30
indices = np.arange(n_samples)
actual = y_test[:n_samples]
lgbm_pred_subset = lgbm_pred[:n_samples]
gru_pred_subset = gru_pred[:n_samples]
ensemble_pred_subset = ensemble_pred[:n_samples]

plt.figure(figsize=(10, 6))
plt.plot(indices, actual, marker='o', color='blue', linestyle='-', label='Actual')
plt.plot(indices, gru_pred_subset, marker='^', color='green', linestyle='--', label='GRU Prediction')
plt.plot(indices, lgbm_pred_subset, marker='s', color='red', linestyle='--', label='LGBM Prediction')
plt.plot(indices, ensemble_pred_subset, marker='*', color='purple', linestyle='--', label='Ensemble')
plt.title('Milk Quality Prediction: Actual vs GRU, LGBM & Ensemble', fontsize=14)
plt.xlabel('Sample Index', fontsize=12)
plt.ylabel('Grade (Encoded)', fontsize=12)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.savefig('model_performance.png')
plt.close()

print(f"LightGBM Accuracy: {lgbm_accuracy:.4f}")
print(f"XGBoost Accuracy: {xgb_accuracy:.4f}")
print(f"GRU Accuracy: {gru_accuracy:.4f}")
print(f"Ensemble Accuracy: {ensemble_accuracy:.4f}")
print("Performance graph saved as 'model_performance.png'")
print("Note: Encoded grades - 2: normal, 1: subclinical mastitis, 0: clinical mastitis")