const express = require('express');
const axios = require('axios');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files (like index.html and model_performance.png)
app.use(express.static(__dirname));

// Serve the index.html file at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle prediction requests
app.post('/predict', async (req, res) => {
    try {
        // Forward the request to the Flask server
        const response = await axios.post('http://localhost:5000/predict', req.body);
        res.json(response.data);
    } catch (error) {
        console.error('Error communicating with Flask server:', error.message);
        res.status(500).json({ error: 'Failed to get prediction from Flask server' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Node.js server running at http://localhost:${port}`);
});