import streamlit as st
import numpy as np
import joblib
from tensorflow.keras.models import load_model

# Load models and encoders
lgbm = joblib.load('lgbm_model.pkl')
xgb = joblib.load('xgb_model.pkl')
scaler = joblib.load('scaler.pkl')
label_encoder = joblib.load('label_encoder.pkl')
gru_model = load_model('gru_model.h5')

# Title
st.title("Mastitis Type Prediction")

# Input form
st.header("Enter Cow Data:")
age = st.number_input("Age in years", min_value=1.0, max_value=20.0, value=5.0)
parity = st.number_input("Parity", min_value=1, max_value=10, value=2)
stage = st.number_input("Stage of Lactation (days)", min_value=0.0, max_value=400.0, value=60.0)
gba = st.selectbox("G/BA", ['n', 'p'])  # 'n' = 0, 'p' = 1
ph = st.number_input("pH", min_value=6.0, max_value=8.0, value=6.7)
cond = st.number_input("Conductivity", min_value=1.0, max_value=10.0, value=5.0)
cmt = st.selectbox("CMT Score", [0, 1, 2, 3])

if st.button("Predict"):
    # Prepare input
    gba_value = 1 if gba.lower() == 'p' else 0
    features = np.array([[age, parity, stage, gba_value, ph, cond, cmt]])
    scaled_features = scaler.transform(features)

    # Predict with models
    lgbm_pred = lgbm.predict(scaled_features)
    xgb_pred = xgb.predict(scaled_features)
    gru_input = scaled_features.reshape((1, 1, scaled_features.shape[1]))
    gru_pred = np.argmax(gru_model.predict(gru_input), axis=1)

    # Ensemble (majority vote)
    preds = np.array([lgbm_pred[0], xgb_pred[0], gru_pred[0]])
    final_pred = np.bincount(preds).argmax()

    # Decode label
    label = label_encoder.inverse_transform([final_pred])[0]
    st.success(f"Predicted Type: **{label.upper()}**")
